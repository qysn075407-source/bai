# VInputVHF

KMDF + VHF virtual HID starter. User-mode controller submits reports through custom IOCTL; driver submits HID input reports with `VhfReadReportSubmit`.

## Device identity

Default neutral development identity in `driver/Public.h`:

```c
#define VINPUTVHF_VENDOR_ID      0x1209
#define VINPUTVHF_PRODUCT_ID     0x0001
#define VINPUTVHF_VERSION_NUMBER 0x0100
```

Do not use Logitech/Razer/Microsoft/etc. VID/PID pairs. For production, replace these with your own assigned VID/PID or a properly allocated PID.

## Build

Use Visual Studio 2022 + Windows WDK, x64. Driver links `vhfkm.lib` and INF installs `vhf` as LowerFilters.

## Install

```bat
bcdedit /set testsigning on
shutdown /r /t 0
pnputil /add-driver VInputVHF.inf /install
:: or: devcon install VInputVHF.inf Root\VInputVHF
```

## Test

```bat
vinputctl move 20 0
vinputctl click left
vinputctl abs 16384 16384
vinputctl key 04
vinputctl combo 02 16
vinputctl consumer E9
```
