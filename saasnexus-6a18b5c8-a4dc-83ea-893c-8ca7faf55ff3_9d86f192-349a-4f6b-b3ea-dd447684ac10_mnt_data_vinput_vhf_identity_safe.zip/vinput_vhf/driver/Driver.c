#include <ntddk.h>
#include <wdf.h>
#include "Device.h"
DRIVER_INITIALIZE DriverEntry;
NTSTATUS DriverEntry(_In_ PDRIVER_OBJECT DriverObject,_In_ PUNICODE_STRING RegistryPath){WDF_DRIVER_CONFIG config;WDF_DRIVER_CONFIG_INIT(&config,VInputVhfEvtDeviceAdd);return WdfDriverCreate(DriverObject,RegistryPath,WDF_NO_OBJECT_ATTRIBUTES,&config,WDF_NO_HANDLE);} 
NTSTATUS VInputVhfEvtDeviceAdd(_In_ WDFDRIVER Driver,_Inout_ PWDFDEVICE_INIT DeviceInit){UNREFERENCED_PARAMETER(Driver);return VInputVhfCreateDevice(DeviceInit);} 
