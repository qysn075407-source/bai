#pragma once
#include <ntddk.h>
#include <wdf.h>
#include <vhf.h>
#include "Public.h"
typedef struct _DEVICE_CONTEXT { VHFHANDLE VhfHandle; WDFWAITLOCK SubmitLock; } DEVICE_CONTEXT,*PDEVICE_CONTEXT;
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(DEVICE_CONTEXT, DeviceGetContext)
EVT_WDF_DRIVER_DEVICE_ADD VInputVhfEvtDeviceAdd;
EVT_WDF_OBJECT_CONTEXT_CLEANUP VInputVhfEvtDeviceContextCleanup;
EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL VInputVhfEvtIoDeviceControl;
NTSTATUS VInputVhfCreateDevice(_Inout_ PWDFDEVICE_INIT DeviceInit);
NTSTATUS VInputVhfSubmitReport(_In_ WDFDEVICE Device,_In_reads_bytes_(InputLength) PVOID Buffer,_In_ size_t InputLength);
